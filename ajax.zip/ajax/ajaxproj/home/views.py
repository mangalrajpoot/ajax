from django.shortcuts import render
from .models import * 

# Create your views here.
def index(request):
    return render(request,'home/index.html')

def search(request):
    d=request.GET['y']
    data=Person.objects.filter(name__icontains=d)#select * from person where name like d;
    return render(request,'home/search.html',{'data':data})
